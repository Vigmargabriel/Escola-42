/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dictionary.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 18:08:53 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/26 18:09:03 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DICTIONARY_H
#define DICTIONARY_H

typedef struct s_dict {
    char *key;
    char *value;
    struct s_dict *next;
} t_dict;

t_dict *parse_dictionary(const char *path);
void free_dictionary(t_dict *dict);

#endif
