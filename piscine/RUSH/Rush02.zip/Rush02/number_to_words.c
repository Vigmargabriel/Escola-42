/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number_to_words.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 18:10:45 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/26 18:10:57 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <string.h>
#include "number_to_words.h"
#include "utils.h"

char *find_in_dict(const char *key, t_dict *dict) {
    while (dict) {
        if (strcmp(key, dict->key) == 0) {
            return dict->value;
        }
        dict = dict->next;
    }
    return NULL;
}

char *number_to_words(const char *number, t_dict *dict) {
    // Função simplificada, precisa ser estendida para suportar todos os números
    char *word = find_in_dict(number, dict);
    if (word) {
        return strdup(word);
    }
    return NULL;
}
