/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 18:07:49 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/26 18:08:06 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"
#include "number_to_words.h"
#include "utils.h"

void print_error(const char *msg) {
    write(2, msg, strlen(msg));
}

int main(int argc, char *argv[]) {
    if (argc < 2 || argc > 3) {
        print_error("Error\n");
        return 1;
    }

    char *dictionary_path = (argc == 3) ? argv[1] : "numbers.dict";
    char *number_str = (argc == 3) ? argv[2] : argv[1];

    if (!is_valid_number(number_str)) {
        print_error("Error\n");
        return 1;
    }

    t_dict *dictionary = parse_dictionary(dictionary_path);
    if (!dictionary) {
        print_error("Dict Error\n");
        return 1;
    }

    char *result = number_to_words(number_str, dictionary);
    if (!result) {
        print_error("Dict Error\n");
    } else {
        printf("%s\n", result);
        free(result);
    }

    free_dictionary(dictionary);
    return 0;
}
