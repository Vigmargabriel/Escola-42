/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dictionary.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 18:09:36 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/26 18:09:47 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"
#include "utils.h"

t_dict *create_dict_node(const char *key, const char *value) {
    t_dict *node = malloc(sizeof(t_dict));
    if (!node)
        return NULL;
    node->key = strdup(key);
    node->value = strdup(value);
    node->next = NULL;
    return node;
}

void add_dict_node(t_dict **dict, t_dict *node) {
    if (!*dict) {
        *dict = node;
    } else {
        t_dict *temp = *dict;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = node;
    }
}

t_dict *parse_dictionary(const char *path) {
    FILE *file = fopen(path, "r");
    if (!file)
        return NULL;

    char line[1024];
    t_dict *dict = NULL;
    while (fgets(line, sizeof(line), file)) {
        char *key = strtok(line, " :\n");
        char *value = strtok(NULL, " :\n");
        if (key && value) {
            t_dict *node = create_dict_node(key, value);
            if (node) {
                add_dict_node(&dict, node);
            } else {
                fclose(file);
                free_dictionary(dict);
                return NULL;
            }
        }
    }
    fclose(file);
    return dict;
}

void free_dictionary(t_dict *dict) {
    while (dict) {
        t_dict *temp = dict;
        dict = dict->next;
        free(temp->key);
        free(temp->value);
        free(temp);
    }
}
