/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number_to_words.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/26 18:10:09 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/26 18:10:18 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NUMBER_TO_WORDS_H
#define NUMBER_TO_WORDS_H

#include "dictionary.h"

char *number_to_words(const char *number, t_dict *dict);

#endif
