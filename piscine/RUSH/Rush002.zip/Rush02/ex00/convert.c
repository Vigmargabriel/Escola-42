/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   convert.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vigde-ol <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 15:51:50 by vigde-ol          #+#    #+#             */
/*   Updated: 2024/07/27 15:51:57 by vigde-ol         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "convert.h"
#include "utils.h"

int	convert_number_to_words(char *number, t_dict *dict)
{
	t_dict	*entry;

	while (*number)
	{
		entry = dict;
		while (entry)
		{
			if (entry->number == (unsigned long long)atoi(number))
			{
				write(1, entry->word, ft_strlen(entry->word));
				write(1, " ", 1);
				break;
			}
			entry = entry->next;
		}
		number++;
	}
	return (1);
}
